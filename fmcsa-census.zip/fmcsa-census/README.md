# FMCSA Carrier Census

Streamlit alat za pretragu američkih prevoznika registrovanih kod FMCSA. Podaci se povlače uživo iz FMCSA Company Census fajla (data.transportation.gov). Korisnik filtrira po državi i statusu operatera, vidi tabelu sa kolonama Company, Phone, State i Power Units, i preuzima rezultate kao CSV. Pristup je zaštićen lozinkom.

## Sadržaj repozitorijuma

```
fmcsa-census/
├── app.py                          # aplikacija
├── requirements.txt                # Python paketi (Streamlit verzija je fiksirana)
├── .gitignore                      # sprečava da secrets.toml ode na GitHub
├── README.md
└── .streamlit/
    ├── config.toml                 # tema i skriven developer meni
    └── secrets.toml.example        # šablon za lozinku i API token
```

## 1. Lokalno pokretanje (za testiranje)

Potreban je Python 3.11 ili noviji.

```bash
cd fmcsa-census
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# otvori .streamlit/secrets.toml i upiši svoju lozinku

streamlit run app.py
```

Aplikacija se otvara na http://localhost:8501.

## 2. Postavljanje na GitHub

1. Na GitHub-u napravi novi **privatni** repozitorijum, npr. `fmcsa-census`. Ne dodaji README ni .gitignore pri kreiranju, jer ih projekat već ima.
2. U terminalu, iz foldera projekta:

```bash
git init
git add .
git status        # proveri da .streamlit/secrets.toml NIJE na listi
git commit -m "FMCSA carrier census app"
git branch -M main
git remote add origin https://github.com/TVOJ-USERNAME/fmcsa-census.git
git push -u origin main
```

Ako umesto terminala fajlove prevlačiš kroz GitHub web interfejs: macOS i Windows podrazumevano sakrivaju fajlove koji počinju tačkom (`.gitignore`, `.streamlit`). Na Mac-u ih prikazuješ sa Cmd + Shift + tačka. Folder `.streamlit` sa `config.toml` je poželjan, ali aplikacija radi i bez njega.

## 3. Objavljivanje na Streamlit Community Cloud

1. Idi na https://share.streamlit.io i prijavi se preko GitHub naloga. Dozvoli pristup privatnim repozitorijumima kada te pita.
2. Klikni **Create app** i izaberi deploy iz GitHub repozitorijuma.
3. Popuni:
   - **Repository:** `TVOJ-USERNAME/fmcsa-census`
   - **Branch:** `main`
   - **Main file path:** `app.py`
   - **App URL:** npr. `ime-klijenta-carriers` (adresa će biti `ime-klijenta-carriers.streamlit.app`)
4. Otvori **Advanced settings**:
   - **Python version:** 3.12
   - **Secrets:** nalepi:
     ```toml
     APP_PASSWORD = "jaka-lozinka-za-klijenta"
     # SOCRATA_APP_TOKEN = "tvoj_token"
     ```
5. Klikni **Deploy**. Prvo pokretanje traje par minuta dok se instaliraju paketi.

## 4. Deljenje sa klijentom

Aplikacija iz privatnog repozitorijuma je podrazumevano privatna, pa je klijent ne može otvoriti bez Streamlit poziva. Pošto je alat zaštićen lozinkom, najjednostavnije je da je učiniš javnom:

1. U aplikaciji otvori **Settings → Sharing**.
2. Izaberi **This app is public and searchable**.
3. Klijentu pošalji link i lozinku (odvojeno, npr. link mejlom, a lozinku porukom).

Kod ostaje privatan na GitHub-u. Javan je samo link do aplikacije, a bez lozinke se vidi samo ekran za prijavu.

## 5. Održavanje

- **Izmene koda:** uradi `git push` na `main` i Streamlit Cloud automatski ponovo pokreće aplikaciju.
- **Promena lozinke:** Settings → Secrets, izmeni `APP_PASSWORD` i sačuvaj. Aplikacija se restartuje sa novom lozinkom.
- **Socrata app token (opciono):** registruj se na data.transportation.gov i u podešavanjima profila (Developer Settings) napravi app token. Dodaj ga u Secrets kao `SOCRATA_APP_TOKEN`. Bez tokena alat radi, ali uz niži limit zahteva.

## Rešavanje problema

| Problem | Rešenje |
|---|---|
| "This app has gone to sleep" | Aplikacija se na besplatnom planu uspava posle perioda bez poseta. Klikni dugme za buđenje i sačekaj oko minut. |
| Žuto upozorenje "Password protection is off" | `APP_PASSWORD` nije podešen u Secrets. Dodaj ga i sačuvaj. |
| "rate limiting requests" | Previše zahteva ka FMCSA API-ju. Sačekaj minut ili dodaj `SOCRATA_APP_TOKEN`. |
| Učitavanje traje predugo | Smanji "Max rows to load" u sidebar-u ili izaberi manje država. |
| Greška pri instalaciji na Cloud-u | Proveri da je u Advanced settings izabran Python 3.12, pa u meniju aplikacije klikni Reboot. |
