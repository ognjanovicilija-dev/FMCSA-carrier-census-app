# FMCSA Carrier Census

Streamlit alat za pretragu američkih prevoznika registrovanih kod FMCSA. Podaci se povlače uživo iz FMCSA Company Census fajla (data.transportation.gov). Korisnik filtrira po državi, statusu operatera i tipu prevoznika (owner-operatori sa jednim kamionom ili svi), vidi tabelu sa kolonama Company, Phone, State i Power Units, i preuzima rezultate kao CSV.

## Sadržaj repozitorijuma

```
fmcsa-census/
├── app.py              # aplikacija
├── requirements.txt    # Python paketi
├── .gitignore
├── README.md
└── .streamlit/
    └── config.toml     # tema i skriven developer meni
```

## 1. Postavljanje na GitHub

1. Na GitHub-u napravi novi repozitorijum, npr. `fmcsa-census`. Ne dodaji README ni .gitignore pri kreiranju.
2. U terminalu, iz foldera projekta:

```bash
git init
git add .
git commit -m "FMCSA carrier census app"
git branch -M main
git remote add origin https://github.com/TVOJ-USERNAME/fmcsa-census.git
git push -u origin main
```

**Javni ili privatni repo?** Ako je repo javni, aplikacija je odmah javna i klijent je otvara samo preko linka. Ako je repo privatni, posle objavljivanja moraš da uradiš i korak 3 ispod.

## 2. Objavljivanje na Streamlit Community Cloud

1. Idi na https://share.streamlit.io i klikni **Continue with GitHub**.
2. Klikni **Create app** i izaberi deploy iz GitHub repozitorijuma.
3. Popuni:
   - **Repository:** `TVOJ-USERNAME/fmcsa-census`
   - **Branch:** `main`
   - **Main file path:** `app.py`
   - **App URL:** npr. `ime-klijenta-carriers`
4. Klikni **Deploy** i sačekaj 2 do 5 minuta.

Dobijaš link oblika `ime-klijenta-carriers.streamlit.app`.

## 3. Samo ako je repo privatni

U aplikaciji otvori **Settings → Sharing** i izaberi **This app is public and searchable**. Bez ovog koraka klijent bi morao da se prijavljuje na Streamlit da bi video aplikaciju.

## 4. Slanje klijentu

Pošalji mu link. Aplikacija se na besplatnom planu uspava posle perioda bez poseta. Tada se prikaže dugme za buđenje, a aplikacija se vraća za oko minut.

## Izmene kasnije

Uradi `git push` na `main` i aplikacija se sama ažurira.

## Lokalno pokretanje (opciono, za testiranje)

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Opciono: Socrata app token

Ako se pojavi poruka "rate limiting requests", FMCSA API ograničava broj zahteva. Registruj se na data.transportation.gov i u podešavanjima profila (Developer Settings) napravi app token. Na Streamlit Cloud-u ga dodaj u **Settings → Secrets**:

```toml
SOCRATA_APP_TOKEN = "tvoj_token"
```

## Rešavanje problema

| Problem | Rešenje |
|---|---|
| "This app has gone to sleep" | Klikni dugme za buđenje i sačekaj oko minut. |
| Klijent mora da se prijavljuje | Repo je privatan, a aplikacija nije javna. Uradi korak 3. |
| Učitavanje traje predugo | Smanji "Max rows to load" u sidebar-u ili izaberi manje država. |
| Greška pri instalaciji na Cloud-u | U Settings izaberi Python 3.12, pa u meniju aplikacije klikni Reboot. |
